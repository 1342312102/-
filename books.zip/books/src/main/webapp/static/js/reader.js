$(function () {
	
    $('#btn_login').click(function () {
        window.location.href = "login.jsp";
	});
	
});

