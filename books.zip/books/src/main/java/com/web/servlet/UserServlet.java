package com.web.servlet;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;

import com.entity.UserDB;
import com.google.gson.Gson;
import com.service.UserService;
import com.utils.MD5;
import com.utils.PageTool;
import com.utils.PaginationUtils;
import com.utils.ResBean;

/**
 * 用户
 * @author RIN
 *
 */
@WebServlet("/user")
public class UserServlet extends BaseServlet {

	private static final long serialVersionUID = 1L;
	
	private UserService userService = new UserService();
	
	/**
	 * 查找用户列表
	 * @param request
	 * @param response
	 * @throws IOException 
	 * @throws ServletException 
	 */
	public void list(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String currentPage = request.getParameter("pageNum");
		String pageSize = request.getParameter("pageSize");
		PageTool<UserDB> pageTool = userService.list(currentPage, pageSize, null);
		//生成前端分页按钮
		String pagation = PaginationUtils.getPagation(pageTool.getTotalCount(), pageTool.getCurrentPage(), pageTool.getPageSize(), "user?method=list");
		request.setAttribute("pagation", pagation);
		request.setAttribute("uList", pageTool.getRows());
		request.getRequestDispatcher("admin/admin_user.jsp").forward(request, response);
	}
	
	public void addUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, IllegalAccessException, InvocationTargetException {
		UserDB userDB = new UserDB();
		BeanUtils.populate(userDB, request.getParameterMap());
		userDB.setTimes(0);//设置借阅次数为0
		userDB.setPassword(MD5.valueOf(userDB.getPassword()));
		System.out.println(userDB);
		userService.addUser(userDB);//添加到数据库
		response.sendRedirect("user?method=list");//调用list方法刷新页面
	}

	/**
	 * 校验用户账号是否存在
	 * @param request
	 * @param response
	 * @throws IOException 
	 */
	public void checkUser(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String account = request.getParameter("account");
		UserDB userDB = new UserDB();
		userDB.setAccount(account);
		List<UserDB> list = userService.getList(userDB);
		ResBean resBean = new ResBean();
		if (list != null && list.size() > 0) {
			resBean.setCode(400);
			resBean.setMsg("账号被占用");
			//实时返回
		} else {
			resBean.setCode(200);
			resBean.setMsg("账号可以使用");
		}
		//将 resBean 转换成 json字符串
		Gson gson = new Gson();
		String json = gson.toJson(resBean);
		response.getWriter().print(json);
		
	}
	/**
	 * 管理员修改用户信息
	 * @param request
	 * @param response
	 */
	public void updUser(HttpServletRequest request, HttpServletResponse response) throws Exception {
		UserDB userDB = new UserDB();
		BeanUtils.populate(userDB, request.getParameterMap());
		userService.updUser(userDB);
		response.sendRedirect("user?method=list");
	}
	
	/**
	 * 管理员删除用户信息
	 * @param request
	 * @param response
	 */
	public void delUser(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String uid = request.getParameter("uid");
		userService.delUser(Integer.parseInt(uid));
		response.sendRedirect("user?method=list");
	}
	
}
