package com.service;

import java.util.List;

import com.dao.UserDao;
import com.entity.UserDB;
import com.utils.PageTool;

/**
 * 用户业务层
 * @author RIN
 *
 */
public class UserService {

	private UserDao userDao = new UserDao();
	/**
	 * 登陆
	 * @param account
	 * @param password
	 * @return
	 */
	public UserDB login(String account,String password) {
		return userDao.login(account, password);
	}
	
	/**
	 * 用户添加
	 * @param userDB
	 * @return
	 */
	public Integer addUser(UserDB userDB) {
		return userDao.addUser(userDB);
	}
	/**
	 * 分页查询
	 * @param currentPage
	 * @param pageSize
	 * @param order
	 * @return
	 */
	public PageTool<UserDB> list(String currentPage, String pageSize, Integer order){
		return userDao.list(currentPage, pageSize, order);
	}
	/**
	 * 管理员修改用户信息
	 * @param userDB
	 * @return
	 */
	public Integer updUser(UserDB userDB) {
		return userDao.updUser(userDB);		
	}
	public List<UserDB> getList(UserDB userDB){
		return userDao.getList(userDB);
	}
	/**
	 * 管理员删除用户信息
	 * @param userDB
	 * @return
	 */
	public Integer delUser(Integer uid) {
		return userDao.delUser(uid);		
	}
}
