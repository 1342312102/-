package com.service;


import java.util.List;

import com.dao.TypeDao;
import com.entity.TypeDB;
import com.utils.PageTool;

/**
 * 图书类别
 * @author Administrator
 *
 */
public class TypeService {

	private TypeDao typeDao = new TypeDao();
	/**
	 * 分页
	 * @param currentPage
	 * @param pageSize
	 * @return
	 */
	public PageTool<TypeDB> listByPage(String currentPage, String pageSize){
		return typeDao.listByPage(currentPage, pageSize);
	}
	
	/**
	 * 多条件查询
	 * @param tid
	 * @param typeName
	 * @return
	 */
	public List<TypeDB> list(String tid,String typeName) {
		return typeDao.list(tid, typeName);
	}
	
	/**
	 * 添加
	 * @param typeName
	 * @return
	 */
	public Integer addType(String typeName) {
		return typeDao.addType(typeName);
	}
	/**
	 * 删除
	 * @param tid
	 * @return
	 */
	public int delType(Integer tid) {
		return typeDao.delType(tid);
	}
	
}
