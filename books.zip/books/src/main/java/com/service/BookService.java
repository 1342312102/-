package com.service;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import com.dao.BookDao;
import com.dao.UserDao;
import com.dao.HistoryDao;
import com.entity.BookDB;
import com.entity.HistoryDB;
import com.entity.UserDB;
import com.utils.MyException;
import com.utils.PageTool;

public class BookService {

	private BookDao bookDao = new BookDao();
	
	private HistoryDao historyDao = new HistoryDao();
	
	private UserDao userDao = new UserDao();
	
	/**
	 * 图书分页查询
	 * @param currentPage
	 * @param pageSize
	 * @return
	 */
	public PageTool<BookDB> listByPage(String currentPage, String pageSize, String word, Integer order){
		return bookDao.list(currentPage, pageSize, word, order);
	}
	/**
	 * 校验
	 * @param bookName
	 * @return
	 */
	public List<BookDB> list(String bookName){
		return bookDao.list(bookName, null);
	}
	
	/**
	 * 添加
	 */
	public Integer addBook(BookDB bookDB) {
		return bookDao.addBook(bookDB);
	}
	
	/**
	 * 修改
	 */
	public Integer updBook(BookDB bookDB) {
		return bookDao.updBook(bookDB);
	}
	/**
	 * 删除
	 * @param bid
	 * @return
	 */
	public int delBook(String bid) {
		return bookDao.delBook(bid);
	}
	

}
